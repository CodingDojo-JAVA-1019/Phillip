import java.util.ArrayList;


public class Basic13Test{
    public static void main(String[] args) {
        
        // Basic13 a= new Basic13();
        // System.out.println(a.print255());

        // Basic13 b = new Basic13();
        // System.out.println(b.printOdd255());
        
        Basic13 c = new Basic13();
        // System.out.println(c.printSum255());

        int[] myArray = {4,8,-18,5,-9};

        System.out.println(c.shiftValues(myArray));
    }
}