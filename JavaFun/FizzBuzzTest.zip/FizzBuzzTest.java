public class FizzBuzzTest{
    public static void main(String[] args) {
        FizzBuzz fb = new FizzBuzz();
        String result = fb.fizzBuzz(17);
        System.out.println(result);

    }
}