package com.phillip.helloHuman;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/")

public class HomeController {

	@RequestMapping("")
	public String helloCD(@RequestParam(value="name", required=false)String name, @RequestParam(value="last_name", required = false)String last_name) {
		if(name != null && last_name == null) {
			return "<h1>Hello "+name+"!</h1><br><br><h3>Welcome to SpringBoot!</h3>";
		}
		if(last_name== null && name== null) {
			return "<h1>Hello Human!</h1><br><br><h3>Welcome to SpringBoot!</h3>";
		}
		if(last_name!= null && name== null) {
			return "<h1>Hello Human!</h1><br><br><h3>Welcome to SpringBoot!</h3>";
		}
		else {
			return "<h1>Hello "+name+" "+last_name+"!</h1><br><br><h3>Welcome to SpringBoot!</h3>";
		}
	
	}
}
